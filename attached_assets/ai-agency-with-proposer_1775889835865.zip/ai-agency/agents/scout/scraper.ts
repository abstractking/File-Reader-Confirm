// agents/scout/scraper.ts
// ═════════════════════════════════════════════
//  Google Maps Places API scraper
//  Uses the official Places API (Text Search +
//  Place Details) — no browser automation needed.
//
//  Required secret: GOOGLE_PLACES_API_KEY
//  Get free key: console.cloud.google.com
//  Enable: "Places API"
//  Free tier: 1,000 requests/day → plenty for this system
// ═════════════════════════════════════════════

import { GOOGLE_PLACES_BASE, MAX_RESULTS_PER_SEARCH } from "./config";
import { log } from "../../core/logger";

export interface RawLead {
  business_name: string;
  contact_name:  string | null;
  phone:         string | null;
  email:         string | null;
  website_url:   string | null;
  address:       string | null;
  location:      string;
  niche:         string;
  rating:        number | null;
  review_count:  number | null;
  place_id:      string;
  google_url:    string;
  notes:         string;
}

// ─────────────────────────────────────────────
// Main scrape function
// ─────────────────────────────────────────────
export async function scrapeGoogleMaps(
  niche:    string,
  location: string
): Promise<RawLead[]> {
  const apiKey = process.env.GOOGLE_PLACES_API_KEY;

  if (!apiKey) {
    await log("SCOUT", "missing_api_key", { hint: "Add GOOGLE_PLACES_API_KEY to Replit Secrets" }, "warning");
    // Return mock data so you can test the pipeline without the API key
    return getMockLeads(niche, location);
  }

  try {
    const query  = `${niche} in ${location}`;
    const places = await textSearch(query, apiKey);

    if (!places.length) return [];

    // Fetch detail for each place (phone, website, etc.)
    const detailed = await Promise.all(
      places.slice(0, MAX_RESULTS_PER_SEARCH).map(p =>
        getPlaceDetails(p.place_id, apiKey, niche, location)
      )
    );

    return detailed.filter((d): d is RawLead => d !== null);

  } catch (err: any) {
    await log("SCOUT", "scrape_error", { niche, location, error: err.message }, "error");
    return [];
  }
}

// ─────────────────────────────────────────────
// Google Places Text Search
// Returns list of places matching query
// ─────────────────────────────────────────────
async function textSearch(
  query:  string,
  apiKey: string
): Promise<{ place_id: string; name: string }[]> {
  const url = new URL(`${GOOGLE_PLACES_BASE}/textsearch/json`);
  url.searchParams.set("query",  query);
  url.searchParams.set("key",    apiKey);
  url.searchParams.set("type",   "establishment");

  const res  = await fetch(url.toString());
  const data = await res.json() as any;

  if (data.status !== "OK" && data.status !== "ZERO_RESULTS") {
    throw new Error(`Places API error: ${data.status} — ${data.error_message ?? ""}`);
  }

  return (data.results ?? []).map((r: any) => ({
    place_id: r.place_id,
    name:     r.name,
  }));
}

// ─────────────────────────────────────────────
// Google Place Details
// Fetches phone, website, address, hours etc.
// ─────────────────────────────────────────────
async function getPlaceDetails(
  placeId:  string,
  apiKey:   string,
  niche:    string,
  location: string
): Promise<RawLead | null> {
  const fields = [
    "name", "formatted_phone_number", "website",
    "formatted_address", "rating", "user_ratings_total",
    "url", "business_status",
  ].join(",");

  const url = new URL(`${GOOGLE_PLACES_BASE}/details/json`);
  url.searchParams.set("place_id", placeId);
  url.searchParams.set("fields",   fields);
  url.searchParams.set("key",      apiKey);

  const res  = await fetch(url.toString());
  const data = await res.json() as any;

  if (data.status !== "OK") return null;

  const r = data.result;

  // Skip permanently closed businesses
  if (r.business_status === "PERMANENTLY_CLOSED") return null;

  // Build useful notes for the scorer
  const notes = buildNotes(r);

  return {
    business_name: r.name,
    contact_name:  null,                          // not available via Places API
    phone:         r.formatted_phone_number ?? null,
    email:         null,                          // not available via Places API
    website_url:   r.website ?? null,
    address:       r.formatted_address ?? null,
    location,
    niche,
    rating:        r.rating ?? null,
    review_count:  r.user_ratings_total ?? null,
    place_id:      placeId,
    google_url:    r.url ?? `https://maps.google.com/?cid=${placeId}`,
    notes,
  };
}

// ─────────────────────────────────────────────
// Build human-readable notes for the scorer
// ─────────────────────────────────────────────
function buildNotes(place: any): string {
  const parts: string[] = [];

  if (!place.website)
    parts.push("❗ No website found — high opportunity");

  if (place.rating && place.rating < 3.5)
    parts.push(`⭐ Low rating: ${place.rating}/5 — may need reputation help`);

  if (place.user_ratings_total && place.user_ratings_total < 10)
    parts.push(`📊 Very few reviews (${place.user_ratings_total}) — newer or low-visibility business`);

  if (place.user_ratings_total && place.user_ratings_total > 50 && place.rating >= 4.5)
    parts.push("✅ Established business with strong reviews — may want to upgrade web presence");

  return parts.join(" | ") || "Standard local business";
}

// ─────────────────────────────────────────────
// Mock leads — used when no API key is set
// Lets you test the full pipeline immediately
// ─────────────────────────────────────────────
function getMockLeads(niche: string, location: string): RawLead[] {
  return [
    {
      business_name: `${location} ${niche} Co.`,
      contact_name:  "John Smith",
      phone:         "337-555-0101",
      email:         null,
      website_url:   null,
      address:       `123 Main St, ${location}`,
      location,
      niche,
      rating:        3.8,
      review_count:  7,
      place_id:      "mock_001",
      google_url:    "https://maps.google.com",
      notes:         "❗ No website found — high opportunity | 📊 Very few reviews (7) — newer or low-visibility business",
    },
    {
      business_name: `Quality ${niche} Services`,
      contact_name:  "Maria Garcia",
      phone:         "337-555-0202",
      email:         null,
      website_url:   "http://qualityservice.com",
      address:       `456 Oak Ave, ${location}`,
      location,
      niche,
      rating:        4.2,
      review_count:  23,
      place_id:      "mock_002",
      google_url:    "https://maps.google.com",
      notes:         "Has a basic website — good candidate for upgrade",
    },
    {
      business_name: `Pro ${niche} LLC`,
      contact_name:  null,
      phone:         "337-555-0303",
      email:         null,
      website_url:   null,
      address:       `789 Pine Rd, ${location}`,
      location,
      niche,
      rating:        null,
      review_count:  0,
      place_id:      "mock_003",
      google_url:    "https://maps.google.com",
      notes:         "❗ No website found — high opportunity | 📊 Very few reviews (0) — newer or low-visibility business",
    },
  ];
}
